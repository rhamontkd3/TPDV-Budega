-- phpMyAdmin SQL Dump
-- version 4.2.7.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: 10-Dez-2015 às 23:26
-- Versão do servidor: 5.6.20
-- PHP Version: 5.5.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `tpdvbudega`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `linhavendaprodutos`
--

CREATE TABLE IF NOT EXISTS `linhavendaprodutos` (
`Codigo` int(11) NOT NULL,
  `Quantidade` int(11) DEFAULT NULL,
  `CodigoProdutos` int(11) DEFAULT NULL,
  `CodigoVendas` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estrutura da tabela `produtos`
--

CREATE TABLE IF NOT EXISTS `produtos` (
`Codigo` int(11) NOT NULL,
  `Nome` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `Marca` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `DataFabricacao` timestamp NULL DEFAULT NULL,
  `DataValidade` timestamp NULL DEFAULT NULL,
  `ValorCompra` double NOT NULL,
  `ValorVenda` double NOT NULL,
  `QuantidadeItensComprados` bigint(20) DEFAULT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10 ;

--
-- Extraindo dados da tabela `produtos`
--

INSERT INTO `produtos` (`Codigo`, `Nome`, `Marca`, `DataFabricacao`, `DataValidade`, `ValorCompra`, `ValorVenda`, `QuantidadeItensComprados`) VALUES
(3, 'bolacha ', 'kero', '2015-01-02 03:00:00', '2015-12-18 03:00:00', 2.5, 4, 1),
(4, 'suco', 'kero', '2015-06-20 03:00:00', '2015-12-24 03:00:00', 2.5, 4, 1),
(5, 'bolachinha ', 'kero', '2015-01-02 03:00:00', '2015-01-02 03:00:00', 2.5, 4, 1),
(6, 'chinelo Alterado', 'importada', '2015-01-02 03:00:00', '2015-12-19 03:00:00', 8, 10, 1),
(7, 'Bolo', 'DuBom', '2015-09-20 03:00:00', '2015-11-23 03:00:00', 3, 4, 0),
(8, 'detergente', 'limpatudo', '2015-01-20 03:00:00', '2015-01-02 03:00:00', 1.7, 2.5, 2),
(9, 'perfume', 'ducheiro', '2015-01-10 03:00:00', '2015-01-24 03:00:00', 7, 10, 0);

-- --------------------------------------------------------

--
-- Estrutura da tabela `venda`
--

CREATE TABLE IF NOT EXISTS `venda` (
`CodigoVenda` int(20) NOT NULL,
  `CpfCliente` bigint(20) NOT NULL,
  `FormaPagamento` varchar(20) DEFAULT NULL,
  `DinheiroPago` double NOT NULL,
  `Troco` double NOT NULL,
  `NumeroCartao` int(11) NOT NULL,
  `TotalPagar` double NOT NULL,
  `DataVenda` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=144 ;

--
-- Extraindo dados da tabela `venda`
--

INSERT INTO `venda` (`CodigoVenda`, `CpfCliente`, `FormaPagamento`, `DinheiroPago`, `Troco`, `NumeroCartao`, `TotalPagar`, `DataVenda`) VALUES
(2, 30405, 'cartao', 20, 2, 2031234, 18, '2015-11-28 01:59:53'),
(3, 30405, 'cartao', 20, 2, 2031234, 18, '2015-11-28 01:59:53'),
(4, 206405, 'cartao', 30, 2, 2134456, 28, '2015-11-28 01:59:53'),
(5, 206405, 'cartao', 30, 2, 2134456, 28, '2015-11-28 01:59:53'),
(6, 30405, 'cartao', 30, 2, 2031234, 28, '2015-11-28 01:59:53'),
(7, 206304, 'cartao', 30, 2, 2031234, 28, '2015-11-28 01:59:53'),
(8, 206304, 'cartao', 30, 2, 2031234, 28, '2015-11-28 01:59:53'),
(9, 206304, 'cartao', 30, 2, 21345, 28, '2015-11-28 01:59:53'),
(10, 206304, 'cartao', 30, 2, 2031234, 28, '2015-11-28 01:59:53'),
(37, 206304, 'cartao', 30, 2, 21345, 28, '2015-11-28 01:59:53'),
(38, 206304, 'cartao', 30, 2, 21345, 28, '2015-11-28 01:59:53'),
(39, 206304, 'cartao', 30, 2, 21345, 28, '2015-11-28 01:59:53'),
(40, 206304, 'cartao', 30, 2, 21345, 28, '2015-11-28 01:59:53'),
(41, 206304, 'cartao', 30, 2, 2031234, 28, '2015-11-28 01:59:53'),
(47, 206304, 'cartao', 30, 2, 2031234, 28, '2015-11-28 01:59:53'),
(48, 206304, 'cartao', 30, 2, 2031234, 28, '2015-11-28 01:59:53'),
(49, 206304, 'cartao', 30, 2, 2031234, 28, '2015-11-28 01:59:53'),
(50, 206304, 'cartao', 30, 2, 2031234, 28, '2015-11-28 01:59:53'),
(51, 206304, 'cartao', 30, 2, 2031234, 28, '2015-11-28 01:59:53'),
(52, 206304, 'cartao', 30, 2, 2031234, 28, '2015-11-28 01:59:53'),
(53, 206304, 'cartao', 30, 2, 2031234, 28, '2015-11-28 01:59:53'),
(54, 206304, 'cartao', 30, 2, 2031234, 28, '2015-11-28 01:59:53'),
(55, 206304, 'dinheiro', 0, 0, 2031234, 28, '2015-11-28 01:59:53'),
(58, 30405, 'dinheiro', 30, 2, 2031234, 28, '2015-11-28 01:59:53'),
(59, 30405, 'dinheiro', 30, 2, 2031234, 28, '2015-11-28 01:59:53'),
(60, 206304, 'cartao', 0, 0, 2134456, 0, '2015-11-28 01:59:53'),
(61, 206304, 'cartao', 0, 0, 2134456, 0, '2015-11-28 01:59:53'),
(62, 91945689, 'cartao', 0, 0, 2134456, 8, '2015-11-28 01:59:53'),
(63, 206304, 'cartao', 0, 0, 2134456, 8, '2015-11-28 01:59:53'),
(64, 206304, 'cartao', 0, 0, 2134456, 8, '2015-11-28 01:59:53'),
(65, 206304, 'cartao', 30, 2, 2031234, 28, '2015-11-28 01:59:53'),
(66, 206304, 'cartao', 30, 2, 2031234, 28, '2015-11-28 01:59:53'),
(67, 30405, 'dinheiro', 30, 2, 0, 28, '2015-11-28 01:59:53'),
(68, 30405, 'dinheiro', 30, 2, 0, 28, '2015-11-28 01:59:53'),
(69, 30405, 'dinheiro', 30, 2, 0, 28, '2015-11-28 01:59:53'),
(70, 206304, 'dinheiro', 30, 2, 0, 28, '2015-11-28 01:59:53'),
(72, 206304, 'cartao', 0, 0, 2031234, 0, '2015-11-28 01:59:53'),
(73, 206304, 'cartao', 0, 0, 2031234, 28, '2015-11-28 01:59:53'),
(74, 206304, 'cartao', 0, 0, 2031234, 28, '2015-11-28 01:59:53'),
(75, 213457, '213489', 0, 0, 234578, 28, '2015-11-28 01:59:53'),
(76, 206304, 'cartao', 0, 0, 2031234, 28, '2015-11-28 01:59:53'),
(77, 206304, 'cartao', 0, 0, 2031234, 8, '2015-11-28 01:59:53'),
(78, 206304, 'cartao', 0, 0, 2031234, 8, '2015-11-28 01:59:53'),
(79, 206304, 'cartao', 0, 0, 21345, 8, '2015-11-28 01:59:53'),
(80, 206304, 'cartao', 0, 0, 2031234, 8, '2015-11-28 01:59:53'),
(81, 30405, 'cartao', 0, 0, 21345, 28, '2015-11-28 01:59:53'),
(82, 234578, 'cartao', 0, 0, 1234589, 28, '2015-11-28 01:59:53'),
(83, 234578, 'cartao', 0, 0, 1234589, 28, '2015-11-28 01:59:53'),
(84, 234578, 'cartao', 0, 0, 1234589, 28, '2015-11-28 01:59:53'),
(87, 234578, 'cartao', 0, 0, 1234589, 28, '2015-11-28 01:59:53'),
(88, 234578, 'cartao', 0, 0, 1234589, 28, '2015-11-28 01:59:53'),
(90, 206304, 'cartao', 0, 0, 2031234, 28, '2015-11-28 01:59:53'),
(91, 206304, 'cartao', 0, 0, 2031234, 8, '2015-11-28 01:59:53'),
(95, 234578, 'cartao', 0, 0, 1234589, 28, '2015-11-28 01:59:53'),
(97, 206304, 'cartao', 0, 0, 2031234, 8, '2015-11-28 01:59:53'),
(98, 206304, 'dinheiro', 30, 2, 0, 28, '2015-11-28 01:59:53'),
(102, 206304, 'dinheiro', 30, 2, 0, 28, '2015-11-28 01:59:53'),
(103, 206304, 'cartao', 0, 0, 2031234, 28, '2015-11-28 01:59:53'),
(107, 206304, 'cartao', 0, 0, 2031234, 28, '2015-11-28 01:59:53'),
(108, 206304, 'cartao', 0, 0, 2031234, 28, '2015-11-28 01:59:53'),
(111, 206304, 'cartao', 0, 0, 2031234, 28, '2015-11-28 01:59:53'),
(112, 206304, 'cartao', 0, 0, 2031234, 28, '2015-11-28 01:59:53'),
(113, 206304, 'cartao', 0, 0, 2031234, 8, '2015-11-28 01:59:53'),
(114, 206304, 'cartao', 0, 0, 2031234, 28, '2015-11-28 01:59:53'),
(115, 206304, 'cartao', 0, 0, 2031234, 14, '2015-11-28 01:59:53'),
(116, 206304, 'cartao', 0, 0, 2031234, 14, '2015-11-28 01:59:53'),
(117, 206304, 'cartao', 0, 0, 2031234, 8, '2014-02-03 03:00:00'),
(118, 21345, 'cartao', 0, 0, 23467, 8, '2015-02-25 03:00:00'),
(120, 206304, 'cartao', 0, 0, 21345, 14, '2015-01-25 03:00:00'),
(121, 206304, 'cartao', 0, 0, 2031234, 12, '2015-01-20 03:00:00'),
(122, 206304, 'cartao', 0, 0, 2031234, 12, '2015-01-20 03:00:00'),
(123, 206304, 'cartao', 0, 0, 2031234, 12, '2013-06-13 03:00:00'),
(124, 206304, 'cartao', 0, 0, 2134456, 8, '2015-01-25 03:00:00'),
(125, 206304, 'cartao', 0, 0, 2134456, 8, '2015-01-25 03:00:00'),
(126, 30405, 'cartao', 0, 0, 2031234, 28, '2015-01-20 03:00:00'),
(127, 30405, 'cartao', 0, 0, 2031234, 28, '2015-01-20 03:00:00'),
(128, 206304, 'cartao', 0, 0, 21345, 8, '2015-01-26 03:00:00'),
(129, 234578, 'cartao', 0, 0, 23567987, 8, '2015-07-12 03:00:00'),
(133, 234567, 'cartao', 0, 0, 245689, 28, '2015-09-10 03:00:00'),
(134, 206304, 'cartao', 0, 0, 2031234, 18, '2015-01-20 03:00:00'),
(135, 206304, 'cartao', 0, 0, 2031234, 18, '2015-01-20 03:00:00'),
(136, 206304, 'cartao', 0, 0, 2031234, 28, '2015-01-20 03:00:00'),
(137, 206304, 'cartao', 0, 0, 2031234, 28, '2015-01-20 03:00:00'),
(138, 206405, 'cartao', 0, 0, 2134456, 8, '2015-01-26 03:00:00'),
(139, 206405, 'cartao', 0, 0, 2134456, 8, '2015-01-26 03:00:00'),
(140, 206304, 'cartao', 0, 0, 2031234, 14, '2015-01-25 03:00:00'),
(141, 206304, 'cartao', 0, 0, 2031234, 8, '2015-01-20 03:00:00'),
(142, 206304, 'cartao', 0, 0, 2031234, 8, '2015-01-14 03:00:00'),
(143, 201234567, 'cartao', 0, 0, 123456, 8, '2015-12-07 03:00:00');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `linhavendaprodutos`
--
ALTER TABLE `linhavendaprodutos`
 ADD PRIMARY KEY (`Codigo`), ADD KEY `CodigoVendas` (`CodigoVendas`), ADD KEY `CodigoProdutos` (`CodigoProdutos`);

--
-- Indexes for table `produtos`
--
ALTER TABLE `produtos`
 ADD PRIMARY KEY (`Codigo`);

--
-- Indexes for table `venda`
--
ALTER TABLE `venda`
 ADD PRIMARY KEY (`CodigoVenda`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `linhavendaprodutos`
--
ALTER TABLE `linhavendaprodutos`
MODIFY `Codigo` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `produtos`
--
ALTER TABLE `produtos`
MODIFY `Codigo` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `venda`
--
ALTER TABLE `venda`
MODIFY `CodigoVenda` int(20) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=144;
--
-- Constraints for dumped tables
--

--
-- Limitadores para a tabela `linhavendaprodutos`
--
ALTER TABLE `linhavendaprodutos`
ADD CONSTRAINT `linhavendaprodutos_ibfk_1` FOREIGN KEY (`CodigoProdutos`) REFERENCES `produtos` (`Codigo`) ON DELETE CASCADE ON UPDATE CASCADE,
ADD CONSTRAINT `linhavendaprodutos_ibfk_2` FOREIGN KEY (`CodigoVendas`) REFERENCES `venda` (`CodigoVenda`) ON DELETE CASCADE ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
