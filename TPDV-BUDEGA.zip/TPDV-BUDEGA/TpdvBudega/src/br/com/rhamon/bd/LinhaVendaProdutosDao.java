package br.com.rhamon.bd;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import br.com.rhamon.mvc.modelo.Venda;

/** 
 * classe Dao do linha de venda
 * 
 * @author
 * */
public class LinhaVendaProdutosDao {
	
	private Connection connection;

	public LinhaVendaProdutosDao() {
		this.connection = new ConnectionFactory().getConnection();
	}

	/**
	 * @param metodo para listar as vendas na nota fiscal
	 * */
	public List<Venda> getListaLinhaVenda() {

		try {
			/**
			 * prepared statement para listar as vendas
			 **/ 
			List<Venda> venda = new ArrayList<Venda>();
			PreparedStatement stmt = this.connection.prepareStatement("select CodigoVenda,QuantidadeItensComprados,Codigo, DataVenda, FormaPagamento, CpfCliente, TotalPagar from venda inner join produtos on produtos.Codigo = venda.CodigoVenda");
			ResultSet rs = stmt.executeQuery();

			while (rs.next()) {
				
				/** criando o objeto venda
				 **/
				Venda v = new Venda();
				v.setCodigoVenda(rs.getLong("CodigoVenda"));
				v.setCpfCliente(rs.getLong("CpfCliente"));

				/**
				 *  montando a data atrav�s do Calendar
				 * */
				Calendar DataVenda = Calendar.getInstance();
				DataVenda.setTime(rs.getDate("DataVenda"));
				v.setDataVenda(DataVenda);
            
				v.setFormaPagamento(rs.getString("FormaPagamento"));
				v.setTotalPagar(rs.getDouble("TotalPagar"));

				/** 
				 * adicionando o objeto � lista
				 **/
				venda.add(v);
			}
			rs.close();
			stmt.close();
			return venda;
		} catch (SQLException e) {
			throw new RuntimeException(e);
		}
	}
	
}
