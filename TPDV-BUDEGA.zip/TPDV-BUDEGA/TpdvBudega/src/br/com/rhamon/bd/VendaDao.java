package br.com.rhamon.bd;


import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import br.com.rhamon.mvc.modelo.Produtos;
import br.com.rhamon.mvc.modelo.Venda;

/** 
 * classe Dao de venda
 * 
 * @author Rhamon
 * */
public class VendaDao {

	private Connection connection;

	public VendaDao() {
		this.connection = new ConnectionFactory().getConnection();
	}
          
	/** 
	 *@param metodo para adicionar venda
	 * 
	 **/
	public void adicionaVenda(Venda venda) {
		
		String sql = "insert into venda (CpfCliente,DataVenda,FormaPagamento,DinheiroPago,Troco,NumeroCartao,TotalPagar) values (?,?,?,?,?,?,?)";
		
		try {
			/**
			 * prepared statement para inser��o
			 * */
			PreparedStatement stmt = connection.prepareStatement(sql);
			
			/** 
			 * seta os valores
			 * */	
			stmt.setLong(1, venda.getCpfCliente());
			stmt.setDate(2, new Date(venda.getDataVenda().getTimeInMillis()));
			stmt.setString(3, venda.getFormaPagamento());
			stmt.setDouble(4, venda.getDinheiroPago());
			stmt.setDouble(5, venda.getTroco());
			stmt.setInt(6, venda.getNumeroCartao());
			stmt.setDouble(7, venda.getTotalPagar());
		
               
			/**
			 * executa
			 * */
			stmt.execute();
			stmt.close();
		} catch (SQLException e) {
			throw new RuntimeException(e);
		}
	}

	
	/**
	 * @param metodo para listar as vendas
	 *  
	 *  */
	public List<Venda> getListaVenda() {

		try {
			/**
			 * prepared statement para listar as vendas
			 * */ 
			List<Venda> venda = new ArrayList<Venda>();
			PreparedStatement stmt = this.connection
					.prepareStatement("select * from venda");
			ResultSet rs = stmt.executeQuery();

			while (rs.next()) {
				/**
				 *  criando o objeto venda
				 * */
				Venda v = new Venda();
				v.setCodigoVenda(rs.getLong("CodigoVenda"));
				v.setCpfCliente(rs.getLong("CpfCliente"));

				/**
				 *  montando a data atrav�s do Calendar
				 * */
				Calendar DataVenda = Calendar.getInstance();
				DataVenda.setTime(rs.getDate("DataVenda"));
				v.setDataVenda(DataVenda);
                v.setDinheiroPago(rs.getDouble("DinheiroPago"));
                v.setTroco(rs.getDouble("Troco"));
                v.setNumeroCartao(rs.getInt("NumeroCartao"));
				v.setFormaPagamento(rs.getString("FormaPagamento"));
				v.setTotalPagar(rs.getDouble("TotalPagar"));

				/**
				 * adicionando o objeto � lista
				 * */
				venda.add(v);
			}
			rs.close();
			stmt.close();
			return venda;
		} catch (SQLException e) {
			throw new RuntimeException(e);
		}
	}
               
	/** 
	 *@param metodo para atualizar as vendas
	 * */
	public void alteraVenda(Venda venda) {
		
		String sql = "update venda set CodigoVenda=?, CpfCliente=?, DataVenda=?, FormaPagamento=?, ValorUnitario=?, Quantidade=?, ValorTotal=?, TotalPagar=? where CodigoVenda=?";
		try {
			PreparedStatement stmt = connection.prepareStatement(sql);
             
			/**
			 * seta os atributos acessado
			 * */
			stmt.setLong(1, venda.getCodigoVenda());
			stmt.setLong(2, venda.getCpfCliente());
			stmt.setDate(3, new Date(venda.getDataVenda().getTimeInMillis()));
			stmt.setString(4, venda.getFormaPagamento());
			stmt.setDouble(5, venda.getTotalPagar());

			stmt.execute();
			stmt.close();
		} catch (SQLException e) {
			throw new RuntimeException(e);
		}
	}
       
	/** 
	 *@param metodo para remover as vendas
	 * */
	public void removeVenda(Venda venda) {
		try {
			/**
			 * conecta ao banco para remover a venda pelo codigo
			 * */
			PreparedStatement stmt = connection
					.prepareStatement("delete from venda where CodigoVenda=?");
			stmt.setLong(1, venda.getCodigoVenda());

			stmt.execute();
			stmt.close();
		} catch (SQLException e) {
			throw new RuntimeException(e);
		}
	}

	/**
	 * @param metodo para acessar a venda pelo codigo
	 * */
	public Venda getVendaByCodigoVenda(String CodigoVenda) {
		Venda venda = new Venda();

		try {
			/**
			 * acessa  a venda e os seus atributos pelo codigo da venda
			 * */ 
			PreparedStatement stmt = this.connection
					.prepareStatement("select * from venda where CodigoVenda=?");
			stmt.setLong(1, Long.parseLong(CodigoVenda));
			ResultSet rs = stmt.executeQuery();

			while (rs.next()) {
				venda.setCodigoVenda(rs.getLong("CodigoVenda"));
				venda.setCpfCliente(rs.getLong("CpfCliente"));

				Calendar dataVenda = Calendar.getInstance();
				dataVenda.setTime(rs.getDate("DataVenda"));
				venda.setDataVenda(dataVenda);

				venda.setFormaPagamento(rs.getString("FormaPagamento"));
				venda.setTotalPagar(rs.getDouble("TotalPagar"));

			}
			rs.close();
			stmt.close();
		} catch (SQLException e) {
			throw new RuntimeException(e);
		}
		return venda;
	}

	public List<Produtos> getListaOrdena() {

		try {
			/**
			 * acessa o banco e lista os produtos com a quantidade maior que zero pelo nome e em ordem crescente
			 * */
			List<Produtos> produto = new ArrayList<Produtos>();
			PreparedStatement stmt = this.connection
					.prepareStatement("select*from produtos where QuantidadeItensComprados > 0 order by Nome asc");
			ResultSet rs = stmt.executeQuery();

			while (rs.next()) {
				
				
					
					/**
					 *  criando o objeto produtos
					 *  */
					Produtos p = new Produtos();
					p.setCodigo(rs.getLong("Codigo"));
					p.setNome(rs.getString("Nome"));
					p.setMarca(rs.getString("Marca"));

					/* montando a data atrav�s do Calendar*/
					Calendar data = Calendar.getInstance();
					data.setTime(rs.getDate("DataFabricacao"));
					p.setDataFabricacao(data);

					Calendar dataValidade = Calendar.getInstance();
					data.setTime(rs.getDate("DataValidade"));
					p.setDataValidade(dataValidade);
					p.setValorCompra(rs.getDouble("ValorCompra"));
					p.setValorVenda(rs.getDouble("ValorVenda"));
					p.setQuantidadeItensComprados(rs
							.getLong("QuantidadeItensComprados"));

					/**
					 * adicionando o objeto � lista
					 * */
					produto.add(p);
				}
			
			
			rs.close();
			stmt.close();
			return produto;
		} catch (SQLException e) {
			throw new RuntimeException(e);
		}
	}

	public List<Venda> getListaFaturamento() {

		try {
			/**
			 * prepared statement para listar as vendas
			 * */ 
			List<Venda> venda = new ArrayList<Venda>();
			PreparedStatement stmt = this.connection
					.prepareStatement("select sum(TotalPagar) as TotalPagar ,DataVenda from venda where DataVenda between Date((DATE_SUB( NOW(), INTERVAL 12 MONTH))) AND DATE (NOW()) group by Month(DataVenda)");
			ResultSet rs = stmt.executeQuery();

			while (rs.next()) {
				/**
				 *  criando o objeto venda
				 * */
				Venda v = new Venda();
				
				/**
				 *  montando a data atrav�s do Calendar
				 * */
				Calendar DataVenda = Calendar.getInstance();
				DataVenda.setTime(rs.getDate("DataVenda"));
				v.setDataVenda(DataVenda);
               	v.setTotalPagar(rs.getDouble("TotalPagar"));

				/**
				 * adicionando o objeto � lista
				 * */
				venda.add(v);
			}
			rs.close();
			stmt.close();
			return venda;
		} catch (SQLException e) {
			throw new RuntimeException(e);
		}
	}

	
}
