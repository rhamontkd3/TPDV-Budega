package br.com.rhamon.bd;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import br.com.rhamon.mvc.modelo.Produtos;
/** 
 * classe Dao de produtos
 * 
 * @author Rhamon
 * */
public class ProdutosDao {

	private Connection connection;
	
	public ProdutosDao() {
		this.connection = new ConnectionFactory().getConnection();
	}
	
	
	public void adiciona(Produtos produtos) {
		String sql = "insert into produtos (Nome,Marca,DataFabricacao,DataValidade,ValorCompra,ValorVenda,QuantidadeItensComprados) values (?,?,?,?,?,?,?)";
		try {
			/**
			 * prepared statement para inser��o
			 *
			 **/
			PreparedStatement stmt = connection.prepareStatement(sql);
			
			/** 
			 *  seta os valores
			 *
			 **/
			
			stmt.setString(1, produtos.getNome());
			stmt.setString(2, produtos.getMarca());
			stmt.setDate(3, new Date(produtos.getDataFabricacao().getTimeInMillis()));
			stmt.setDate(4, new Date(produtos.getDataValidade().getTimeInMillis()));
			stmt.setDouble(5, produtos.getValorCompra());
			stmt.setDouble(6, produtos.getValorVenda());
			stmt.setLong(7, produtos.getQuantidadeItensComprados());
			
			/**
			 * executa
			 * */
			stmt.execute();
			stmt.close();
		} catch (SQLException e) {
			throw new RuntimeException(e);
		}
	}
	
	
	
	/** 
	@param metodo para listar os produtos
	 * */
	public List<Produtos> getLista() {
		
		try {
			List<Produtos> produto = new ArrayList<Produtos>();
			PreparedStatement stmt = this.connection.prepareStatement("select*from produtos");
			ResultSet rs = stmt.executeQuery();
			
			while (rs.next()) {
				/**
				 * criando o objeto produtos
				 * */
				Produtos p = new Produtos();
				
				p.setCodigo(rs.getLong("Codigo"));
				p.setNome(rs.getString("Nome"));
				p.setMarca(rs.getString("Marca"));
				
				/**
				 * montando a data atrav�s do Calendar
				 * */
				Calendar data = Calendar.getInstance();
				data.setTime(rs.getDate("DataFabricacao"));
				p.setDataFabricacao(data);
				
				Calendar dataValidade = Calendar.getInstance();
				data.setTime(rs.getDate("DataValidade"));
				p.setDataValidade(dataValidade);
				
				p.setValorCompra(rs.getDouble("ValorCompra"));
				p.setValorVenda(rs.getDouble("ValorVenda"));
				p.setQuantidadeItensComprados(rs.getLong("QuantidadeItensComprados"));
				
				/** 
				 * adicionando o objeto � lista
				 **/
				produto.add(p);
			}
			rs.close();
			stmt.close();
			return produto;
		} catch (SQLException e) {
			throw new RuntimeException(e);
		}
	}

	
	/**
	 *  metodo para alterar os produtos
	 **/
	public void altera(Produtos produtos) {
		String sql = "update produtos set Codigo=?, Nome=?, Marca=?, DataFabricacao=?, DataValidade=?, ValorCompra=?, ValorVenda=?, QuantidadeItensComprados=? where Codigo=?";
		try {
			PreparedStatement stmt = connection.prepareStatement(sql);
			/*seta os atributos acessado*/
			stmt.setLong(1, produtos.getCodigo());
			stmt.setString(2, produtos.getNome());
			stmt.setString(3, produtos.getMarca());
			stmt.setDate(4, new Date(produtos.getDataFabricacao().getTimeInMillis()));
			stmt.setDate(5, new Date(produtos.getDataValidade().getTimeInMillis()));
			stmt.setDouble(6, produtos.getValorCompra());
			stmt.setDouble(7, produtos.getValorVenda());
			stmt.setLong(8, produtos.getQuantidadeItensComprados());
			stmt.setLong(9, produtos.getCodigo());
			
			stmt.execute();
			stmt.close();
		} catch (SQLException e) {
			throw new RuntimeException(e);
		}
	}

	/**
	 *  metodo para remover os produtos
	 **/
	public void remove( Produtos produtos) {
		try {
			PreparedStatement stmt = connection.prepareStatement("delete from produtos where Codigo=?");
			stmt.setLong(1, produtos.getCodigo());
			
			stmt.execute();
			stmt.close();
		} catch (SQLException e) {
			throw new RuntimeException(e);
		}
	}
	
	
	/** 
	 * metodo para acessar os produtos pelo codigo
	 **/
	public Produtos getProdutosByCodigo(String Codigo) {
		Produtos produtos = new Produtos();
	          	
		try {
			PreparedStatement stmt = this.connection.prepareStatement("select * from produtos where Codigo=?");
			stmt.setLong( 1, Long.parseLong( Codigo));
			ResultSet rs = stmt.executeQuery();

			while (rs.next()) {
				produtos.setCodigo(rs.getLong("Codigo"));
				produtos.setNome(rs.getString("Nome"));
				produtos.setMarca(rs.getString("Marca"));
				
				Calendar data = Calendar.getInstance();
				data.setTime(rs.getDate("DataFabricacao"));
				produtos.setDataFabricacao(data);
				
				Calendar dataValidade = Calendar.getInstance();
				data.setTime(rs.getDate("DataValidade"));
				produtos.setDataValidade(dataValidade);
						
				produtos.setValorCompra(rs.getDouble("ValorCompra"));
				produtos.setValorVenda(rs.getDouble("ValorVenda"));
				produtos.setQuantidadeItensComprados(rs.getLong("QuantidadeItensComprados"));
				
				
			}
			rs.close();
			stmt.close();
		} catch (SQLException e) {
			throw new RuntimeException(e);
		}
		return produtos;
	    }

	
	
	
public List<Produtos> getListaEstoque() {
		
		try {
			List<Produtos> produto = new ArrayList<Produtos>();
			PreparedStatement stmt = this.connection.prepareStatement("select Nome, DataValidade, QuantidadeItensComprados from produtos where QuantidadeItensComprados = 0 OR (DataValidade between CurDate() AND CURDATE() + 15)  group by Nome");
			ResultSet rs = stmt.executeQuery();
			
			while (rs.next()) {
				/**
				 * criando o objeto produtos
				 * */
				Produtos p = new Produtos();
				
				
				/**
				 * montando a data atrav�s do Calendar
				 * */
				p.setNome(rs.getString("Nome"));
				
				
				Calendar dataValidade = Calendar.getInstance();
				dataValidade.setTime(rs.getDate("DataValidade"));
				p.setDataValidade(dataValidade);
				
				
				p.setQuantidadeItensComprados(rs.getLong("QuantidadeItensComprados"));
				
				/** 
				 * adicionando o objeto � lista
				 **/
				produto.add(p);
			}
			rs.close();
			stmt.close();
			return produto;
		} catch (SQLException e) {
			throw new RuntimeException(e);
		}
	}
	

}



