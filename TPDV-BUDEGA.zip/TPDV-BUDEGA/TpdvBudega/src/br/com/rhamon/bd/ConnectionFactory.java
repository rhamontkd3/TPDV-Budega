package br.com.rhamon.bd;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
/**
 *  classe para conectar ao banco
 *  
 * @author Rhamon
 **/
public class ConnectionFactory {

	/** 
	 *@param metodo que faz a conex�o com o banco
	 **/
public Connection getConnection() {
		
		try {
			System.out.println("Conectando ao banco");
			Class.forName("com.mysql.jdbc.Driver");
			return DriverManager.getConnection("jdbc:mysql://localhost:3306/TpdvBudega", "root", "");
		
		} catch (SQLException e) {
			throw new RuntimeException(e);
		} catch (ClassNotFoundException e) {
			throw new RuntimeException(e);
		}
	}
}
