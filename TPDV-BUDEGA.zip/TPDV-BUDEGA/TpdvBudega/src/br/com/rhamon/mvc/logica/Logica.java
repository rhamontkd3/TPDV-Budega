package br.com.rhamon.mvc.logica;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *  interface de Execu��o da logica 
 * 
 *  @author Rhamon
 *  */
public interface Logica {
	void executa(HttpServletRequest req, HttpServletResponse res) throws Exception;

}
