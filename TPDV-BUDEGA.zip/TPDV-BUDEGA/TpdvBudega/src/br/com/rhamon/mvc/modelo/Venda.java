package br.com.rhamon.mvc.modelo;

import java.util.Calendar;
import java.util.List;

/**
 *  classe modelo de venda
 *  
 *  @author Rhamon
 *  */
public class Venda {
	
	/** atributos  de visibilidade privada
	 **/
    private long CodigoVenda;	
	private long CpfCliente;
	private Calendar DataVenda;
	private String FormaPagamento;
	private List<Produtos> ConjuntoItensComprados;
	private double DinheiroPago;
	private double Troco;
	private int NumeroCartao;
	
	
	
	/** metodos get e set
	 * */
	public double getDinheiroPago() {
		return DinheiroPago;
	}

	public void setDinheiroPago(double dinheiroPago) {
		DinheiroPago = dinheiroPago;
	}

	public double getTroco() {
		return Troco;
	}

	public void setTroco(double troco) {
		Troco = troco;
	}

	public int getNumeroCartao() {
		return NumeroCartao;
	}

	public void setNumeroCartao(int numeroCartao) {
		NumeroCartao = numeroCartao;
	}

	private double TotalPagar;
	
	
	
	public long getCodigoVenda() {
		return CodigoVenda;
	}

	public void setCodigoVenda(long codigoVenda) {
		CodigoVenda = codigoVenda;
	}

	
	public long getCpfCliente() {
		return CpfCliente;
	}
	
	public void setCpfCliente(long cpfCliente) {
		CpfCliente = cpfCliente;
	}
	
	public Calendar getDataVenda() {
		return DataVenda;
	}
	
	public void setDataVenda(Calendar dataVenda) {
		DataVenda = dataVenda;
	}
	
	public String getFormaPagamento() {
		return FormaPagamento;
	}
	
	public void setFormaPagamento(String formaPagamento) {
		FormaPagamento = formaPagamento;
	}
	
	public List<Produtos> getConjuntoItensComprados() {
		return ConjuntoItensComprados;
	}
	
	public void setConjuntoItensComprados(List<Produtos> conjuntoItensComprados) {
		ConjuntoItensComprados = conjuntoItensComprados;
	}
	
	
	public double getTotalPagar() {
		return TotalPagar;
	}
	
	public void setTotalPagar(double totalPagar) {
		TotalPagar = totalPagar;
	}

}
