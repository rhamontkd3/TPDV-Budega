package br.com.rhamon.mvc.logica;

import java.text.SimpleDateFormat;

import java.util.Calendar;
import java.util.Date;


import javax.servlet.RequestDispatcher;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import br.com.rhamon.bd.VendaDao;

import br.com.rhamon.mvc.modelo.Venda;

/**
 * classe do servlet do adicionar venda
 * 
 * @author Rhamon
 * **/
public class AdicionaVendaLogica implements Logica {

	@Override
	public void executa(HttpServletRequest request, HttpServletResponse response) throws Exception {
		/**
		 *  cria o objeto venda
		 *  
		 **/		
		Venda venda = new Venda ();
	    
		
		   /**
		    * acessa os parametros no Dao para enviar ao formulario
		    **/ 
		venda.setCpfCliente(Long.parseLong(request.getParameter("CpfCliente")));
	    
		/*convertendo a data de String para Calendar*/
		String DataEmTextoVenda = request.getParameter("DataVenda");
		Date dataFormataVenda = null;
		dataFormataVenda = new SimpleDateFormat("dd/MM/yyyy").parse(DataEmTextoVenda);
		Calendar DataVenda = Calendar.getInstance();
		DataVenda.setTime(dataFormataVenda);
		venda.setDataVenda(DataVenda);
		
		venda.setFormaPagamento(request.getParameter("FormaPagamento"));
		venda.setDinheiroPago(Double.parseDouble(request.getParameter("DinheiroPago")));
		venda.setTroco(Double.parseDouble(request.getParameter("Troco")));
		venda.setNumeroCartao(Integer.parseInt(request.getParameter("NumeroCartao")));
		venda.setTotalPagar(Double.parseDouble(request.getParameter("TotalPagar")));
	
		
		
	    /**
	     * adiciona os objetos a lista 
	     **/
	    VendaDao dao = new VendaDao();
		dao.adicionaVenda(venda);
      
		/**
		 *  separa as Strings por , e depois por : e itera os dois campos
		 **/
		String produtos= request.getParameter("produtos");
		String ArrayProdutos[] = produtos.split(",");
		for (int i=0; i<ArrayProdutos.length; i++){
			
			System.out.println("campo"+ i+":"+ArrayProdutos[i]);
						
			String ArrayCampo[] = ArrayProdutos[i].split(":");
			System.out.println(" c�digo:  " + ArrayCampo[0]+ " quantidade : "+ArrayCampo[1]);
			
		}
		
		
		/** 
		 * despacha a informa��o para o formulario
		 **/
		RequestDispatcher rd = request.getRequestDispatcher("/adiciona-venda.jsp");
		rd.forward(request, response);
		System.out.println("efetuando a  venda de codigo: " + venda.getCodigoVenda());
	    
	}
	
	

}
