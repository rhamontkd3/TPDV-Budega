package br.com.rhamon.mvc.logica;

import javax.servlet.RequestDispatcher;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import br.com.rhamon.bd.ProdutosDao;
import br.com.rhamon.mvc.modelo.Produtos;

/**
 *  classe servlet de produto para remover o produto
 * 
 * @author Rhamon
 * */
public class RemoveProdutosLogica implements Logica {

	@Override
	/**
	 *  metodo executa para remover o produto
	 *  */
	public void executa(HttpServletRequest req, HttpServletResponse res) throws Exception {
		Produtos produtos = new Produtos();

		long Codigo = Long.parseLong(req.getParameter("Codigo"));
		produtos.setCodigo(Codigo);
		
		ProdutosDao dao = new ProdutosDao();
		dao.remove(produtos);
		
		RequestDispatcher rd = req.getRequestDispatcher("/lista-produtos.jsp");
		rd.forward(req, res);
		System.out.println("Removendo produto ..." + produtos.getNome());
	}
		
	}


