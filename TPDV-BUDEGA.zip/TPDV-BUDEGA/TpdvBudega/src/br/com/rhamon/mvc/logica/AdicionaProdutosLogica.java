package br.com.rhamon.mvc.logica;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import javax.servlet.RequestDispatcher;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import br.com.rhamon.bd.ProdutosDao;
import br.com.rhamon.mvc.modelo.Produtos;

public class AdicionaProdutosLogica implements Logica {
	
	 /**
	  * metodo executa da servlet de adiciona produtos
	  **/
	public void executa(HttpServletRequest request, HttpServletResponse response) throws Exception {
		 /**
		  * cria o objeto produtos
		  **/
		Produtos produtos = new Produtos();
		
		 /**
		  * acessa os parametros do Dao para enviar para o formulario
		  **/  
		
		produtos.setNome(request.getParameter("Nome"));
		produtos.setMarca(request.getParameter("Marca"));
		
		/**
		 * convertendo a data de String para Calendar
		 **/
		String DataEmTextoFabricacao = request.getParameter("DataFabricacao");
		Date dataFormataFabricacao = null;
		dataFormataFabricacao = new SimpleDateFormat("dd/mm/yyyy").parse(DataEmTextoFabricacao);
		Calendar DataFabricacao = Calendar.getInstance();
		DataFabricacao.setTime(dataFormataFabricacao);
		
		produtos.setDataFabricacao(DataFabricacao);
		
		
		String DataEmTextoValidade = request.getParameter("DataValidade");
		Date dataFormataValidade = null;
		dataFormataValidade = new SimpleDateFormat("dd/mm/yyyy").parse(DataEmTextoValidade);
		Calendar DataValidade = Calendar.getInstance();
		DataValidade.setTime(dataFormataValidade);    		
		
		produtos.setDataValidade(DataValidade);	
		
		
		produtos.setValorCompra(Double.parseDouble(request.getParameter("ValorCompra")));
		produtos.setValorVenda(Double.parseDouble(request.getParameter("ValorVenda")));
	    produtos.setQuantidadeItensComprados(Long.parseLong(request.getParameter("QuantidadeItensComprados")));
	
	    /** 
	     * adiciona os objetos a lista 
	     **/
	    ProdutosDao dao = new ProdutosDao();
		dao.adiciona(produtos);

		/**
		 * despacha a informa��o para o formulario
		 **/	
		RequestDispatcher rd = request.getRequestDispatcher("/adiciona-produtos.jsp");
		rd.forward(request, response);
		System.out.println("Adicionando produtos: " + produtos.getNome());

	}
}