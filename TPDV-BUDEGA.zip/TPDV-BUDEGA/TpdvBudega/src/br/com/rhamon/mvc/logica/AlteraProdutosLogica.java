package br.com.rhamon.mvc.logica;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import javax.servlet.RequestDispatcher;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import br.com.rhamon.bd.ProdutosDao;
import br.com.rhamon.mvc.modelo.Produtos;

/**
 *  classe  servlet para alterar produtos 
 * 
 * @author Rhamon
 **/
public class AlteraProdutosLogica implements Logica {

	@Override
	/**
	 * metodo para executar o altera e o adiciona de produtos
	 **/
	public void executa(HttpServletRequest request, HttpServletResponse response) throws Exception {
		String paramAltera = request.getParameter("paramAltera");
		
		if(paramAltera.equalsIgnoreCase("altera")){
			this.altera(request, response);
		}else if(paramAltera.equalsIgnoreCase("popula")){
			this.popula(request, response);
		}
	}

	public void popula(HttpServletRequest request, HttpServletResponse response) throws Exception {
		String Codigo = request.getParameter("Codigo");
		ProdutosDao dao = new ProdutosDao();
		
		Produtos produtos = dao.getProdutosByCodigo(Codigo);
		
		request.setAttribute("produtos", produtos);
		RequestDispatcher rd = request.getRequestDispatcher("/altera-produtos.jsp");
		rd.forward(request, response);
		System.out.println("Recebido o Codigo para efetuar a altera��o, " + produtos.getCodigo());
		
	
	}

	/** 
	 * metodo do servlet para alterar
	 **/
	public void altera(HttpServletRequest request, HttpServletResponse response) throws Exception {
		Produtos produtos = new Produtos();
		long Codigo = Long.parseLong(request.getParameter("Codigo"));
		produtos.setCodigo(Codigo);
		produtos.setNome(request.getParameter("Nome"));
		produtos.setMarca(request.getParameter("Marca"));
		
		/*Converte a data de String para Calendar*/
		String DataEmTextoFabricacao = request.getParameter("DataFabricacao");
		Date dataFormataFabricacao = null;
		dataFormataFabricacao = new SimpleDateFormat("dd/mm/yyyy").parse(DataEmTextoFabricacao);
		Calendar DataFabricacao = Calendar.getInstance();
		DataFabricacao.setTime(dataFormataFabricacao);
		
		produtos.setDataFabricacao(DataFabricacao);
		
		String DataEmTextoValidade = request.getParameter("DataValidade");
		Date dataFormataValidade = null;
		dataFormataValidade = new SimpleDateFormat("dd/mm/yyyy").parse(DataEmTextoValidade);
		Calendar DataValidade = Calendar.getInstance();
		DataValidade.setTime(dataFormataValidade);    		
		
		produtos.setDataValidade(DataValidade);	
		
		produtos.setValorCompra(Double.parseDouble(request.getParameter("ValorCompra")));
		produtos.setValorVenda(Double.parseDouble(request.getParameter("ValorVenda")));
	    produtos.setQuantidadeItensComprados(Long.parseLong(request.getParameter("QuantidadeItensComprados")));

		
		ProdutosDao dao = new ProdutosDao();
		dao.altera(produtos);
		
		/**
		 *  despacha a informa��o para o lista produtos
		 **/
		RequestDispatcher rd = request.getRequestDispatcher("/lista-produtos.jsp");
		rd.forward(request, response);
		System.out.println("Alterando Produtos ..." + produtos.getNome());	
	}
}
