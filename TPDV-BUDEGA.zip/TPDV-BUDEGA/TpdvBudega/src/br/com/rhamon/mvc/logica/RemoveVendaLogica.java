package br.com.rhamon.mvc.logica;

import javax.servlet.RequestDispatcher;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import br.com.rhamon.bd.VendaDao;
import br.com.rhamon.mvc.modelo.Venda;

/**
 * classe para remover a venda
 * 
 * @author Rhamon
 * 
 */


/**
 *  classe servlet de venda para remover a venda
 *  
 */
public class RemoveVendaLogica implements Logica {

	/**
	 * executa o remover de venda
	 * 
	 * @param executa
	 */
	@Override
	/** 
	 * meotodo executa de venda para remove-la pelo codigo
	 * 
	 * */
	public void executa(HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		
		Venda venda = new Venda();

		long CodigoVenda = Long.parseLong(request.getParameter("CodigoVenda"));
		venda.setCodigoVenda(CodigoVenda);
		
		VendaDao dao = new VendaDao();
		dao.removeVenda(venda);
		
		RequestDispatcher rd = request.getRequestDispatcher("/lista-venda.jsp");
		rd.forward(request, response);
		System.out.println("Removendo venda de codigo ..." + venda.getCodigoVenda());
		
		
	}

}
