package br.com.rhamon.mvc.modelo;


import java.util.Calendar;

/**
 *  classe modelo de produtos
 *  
 *  @author Rhamon
 **/
public class Produtos {

	/**
	 *  atributos de visibilidade privada
	 * */
	private long Codigo;
	private String Nome;
	private String Marca;
	private Calendar DataFabricacao;
    private Calendar DataValidade;
    private double ValorCompra;
    private double ValorVenda;
    private long QuantidadeItensComprados;
	
    /**
     *  metodos get e set de produtos
     **/
    public long getCodigo() {
		return Codigo;
	}
	public void setCodigo(long codigo) {
		Codigo = codigo;
	}
	public String getNome() {
		return Nome;
	}
	public void setNome(String nome) {
		Nome = nome;
	}
	public String getMarca() {
		return Marca;
	}
	public void setMarca(String marca) {
		Marca = marca;
	}
	public Calendar getDataFabricacao() {
		return DataFabricacao;
	}
	public void setDataFabricacao(Calendar dataFabricacao) {
		DataFabricacao = dataFabricacao;
	}
	public Calendar getDataValidade() {
		return DataValidade;
	}
	public void setDataValidade(Calendar dataValidade) {
		DataValidade = dataValidade;
	}
	public double getValorCompra() {
		return ValorCompra;
	}
	public void setValorCompra(double valorCompra) {
		ValorCompra = valorCompra;
	}
	public double getValorVenda() {
		return ValorVenda;
	}
	public void setValorVenda(double valorVenda) {
		ValorVenda = valorVenda;
	}
	public long getQuantidadeItensComprados() {
		return QuantidadeItensComprados;
	}
	public void setQuantidadeItensComprados(long quantidadeItensComprados) {
		QuantidadeItensComprados = quantidadeItensComprados;
	}
	
}
