package br.com.rhamon.mvc.modelo;

/**
 *  classe modelo de LinhaVendaProdutos
 *
 *@author Rhamon
 **/
public class LinhaVendaProdutos {
	
	/**
	 *  atributos de visibilidade privada
	 **/
	private int Codigo;
	private int Quantidade;
	private int CodigoProdutos;
	private int CodigoVendas;
	
	
	/** metodos get e set
	 **/
	public int getCodigo() {
		return Codigo;
	}
	public void setCodigo(int codigo) {
		Codigo = codigo;
	}
	public int getQuantidade() {
		return Quantidade;
	}
	public void setQuantidade(int quantidade) {
		Quantidade = quantidade;
	}
	public int getCodigoProdutos() {
		return CodigoProdutos;
	}
	public void setCodigoProdutos(int codigoProdutos) {
		CodigoProdutos = codigoProdutos;
	}
	public int getCodigoVendas() {
		return CodigoVendas;
	}
	public void setCodigoVendas(int codigoVendas) {
		CodigoVendas = codigoVendas;
	}
	
}
